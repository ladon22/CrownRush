using System.Collections;
using UnityEngine;

public class TurnManager : MonoBehaviour
{
    public GameManager GameManager;
    public EnemyManager EnemyManager;
    public float TurnDelay = 0.5f;
    public void StartGameLoop()
    {
        EnemyManager.SpawnEnemy();
        StartPlayerTurn();
    }
    
    public void StartPlayerTurn()
    {
        StartCoroutine(DelayStartPlayerTurn());
        Debug.Log("----�÷��̾� ��----");
    }

    public void EndPlayerTurn()
    {
        if (GameManager.CurrentState == GameState.PlayerTurn)
        {
            StartCoroutine(EnemyTurnRoutine());
        }
    }

    private IEnumerator EnemyTurnRoutine()
    {
        GameManager.ChangeState(GameState.EnemyTurn);
        if (EnemyManager != null) EnemyManager.ClearAllIntents();
        yield return new WaitForSeconds(TurnDelay);
        Debug.Log("--- �� �� ���� (�̵� �� ����) ---");

        yield return StartCoroutine(EnemyManager.ProcessEnemiesTurnRoutine());
        StartPlayerTurn();
    }

    private IEnumerator DelayStartPlayerTurn()
    {
        GameManager.ChangeState(GameState.PlayerTurn);
        if (EnemyManager != null) EnemyManager.UpdateEnemyIntents();
        yield return new WaitForSeconds(TurnDelay);
    }

}
