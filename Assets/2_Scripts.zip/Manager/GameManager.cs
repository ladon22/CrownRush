using DG.Tweening;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
public enum GameState
{
    Lobby,
    Initialize,
    PlayerTurn,
    EnemyTurn,
    GameOver
}

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public GameState CurrentState;

    public GridManager GridManager;
    public BoardRenderer BoardRenderer;
    public InputController InputController;
    public TurnManager TurnManager;
    public EnemyManager EnemyManager;
    public HealthUIManager HealthUIManager;
    public ItemManager ItemManager;
    public ScoreManager ScoreManager;
    //public FireBaseManager FireBaseManager;

    public GameObject PlayerPrefab;

    [Header("UI")]
    public UITransitionController UITransition;
    public GameObject LobbyUIPanel;
    public GameObject GameUIPanel;
    public GameOverUIController GameOverUI;
    public SettingsUIController SettingsUI;
    public UpdateBestScoreUI LobbyUI;

    private bool IsInitialized = false;
    private PlayerController CurrentPlayer;

    public CollectionUIController CollectionUI;
    private bool bHasRevivedThisGame = false;
    private const string BestScoreKey = "BestScore";

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        ChangeState(GameState.Lobby);

        if (!IsInitialized)
        {
            InitializeGameStage();
            IsInitialized = true;
        }

        if (AudioManager.Instance != null) AudioManager.Instance.PlayBGM(BgmType.Lobby);
        if (LobbyUIPanel != null) LobbyUIPanel.SetActive(true);
        //if (GameUIPanel != null) GameUIPanel.SetActive(false);
    }

    void Update()
    {
        // ����Ƽ �����Ϳ��� �÷��� ���� ���� �۵��ϴ� ������ ġƮŰ�Դϴ�.
#if UNITY_EDITOR
        if (Keyboard.current != null && Keyboard.current.f12Key.wasPressedThisFrame)
        {
            PlayerPrefs.DeleteAll();
            PlayerPrefs.Save();
            Debug.Log("[Cheat] ��� ������ �ʱ�ȭ �Ϸ�! ���� ������մϴ�.");

            UnityEngine.SceneManagement.SceneManager.LoadScene(
                UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex
            );
        }
#endif
    }
    public void ChangeState(GameState state)
    {
        CurrentState = state;
    }

    private void InitializeGameStage()
    {
        Vector2 PrefabSize = BoardRenderer.GetTileSize();
        GridManager.InitializeGrid(PrefabSize);
        BoardRenderer.GenerateBoardVisuals(GridManager);
        SpawnPlayer();
    }

    private void SpawnPlayer()
    {
        if (PlayerPrefab == null)
        {
            Debug.LogError("PlayerPrefab is null");
            return;
        }

        int StartX = 0;
        int StartY = 0;
        GridManager.GetPlayerStartIndex(out StartX, out StartY);
        Vector2 SpawnPosition = GridManager.GetWorldPosition(StartX, StartY);
        GameObject PlayerInstance = Instantiate(PlayerPrefab, SpawnPosition, Quaternion.identity);
        PlayerInstance.name = "Player";

        CurrentPlayer = PlayerInstance.GetComponent<PlayerController>();

        if (CurrentPlayer != null)
        {
            CurrentPlayer.GridManager = GridManager;
            CurrentPlayer.InputController = InputController;
            CurrentPlayer.CurrentX = StartX;
            CurrentPlayer.CurrentY = StartY;
            CurrentPlayer.TurnManager = TurnManager;
            CurrentPlayer.EnemyManager = EnemyManager;
            CurrentPlayer.ItemManager = ItemManager;
        }

        HealthComponent PlayerHealth = PlayerInstance.GetComponent<HealthComponent>();
        if (PlayerHealth != null && HealthUIManager != null)
        {
            HealthUIManager.InitializeHealthUI(PlayerHealth);
            PlayerHealth.OnDied += GameOver;
        }

        // �÷��̾ ������ ����, ���� ���� ���� ��Ų�� �����ݴϴ�.
        if (CurrentPlayer != null)
        {
            CurrentPlayer.ApplyEquippedSkin();
        }
    }

    public void StartGame(bool IsRetry = false)
    {
        ChangeState(GameState.Initialize);

        float StartDelay = 0f;

        if (!IsRetry)
        {
            if (UITransition != null)
            {
                UITransition.SlideToGame();
                StartDelay = UITransition.SlideDuration;
            }
        }

        //if (LobbyUIPanel != null) LobbyUIPanel.SetActive(false);
        //if (GameUIPanel != null) GameUIPanel.SetActive(true);

        if (GameOverUI != null) GameOverUI.Hide();

        if (ScoreManager != null) ScoreManager.ResetScore();
        if (ItemManager != null) ItemManager.ClearItem();

        ClearEnemies();

        if (CurrentPlayer != null)
        {
            CurrentPlayer.gameObject.SetActive(true);
            CurrentPlayer.ResetPlayer();
        }

        if (AudioManager.Instance != null) AudioManager.Instance.PlayBGM(BgmType.InGame);

        DOVirtual.DelayedCall(StartDelay, () =>
        {
            TurnManager.StartGameLoop();
        });

        bHasRevivedThisGame = false;
    }

    public void GameOver()
    {
        ChangeState(GameState.GameOver);

        // ���� ������ �� ������ ���� �÷��� Ƚ���� ������Ű�� �����մϴ�.
        int PlayCount = PlayerPrefs.GetInt("TotalPlayCount", 0) + 1;
        PlayerPrefs.SetInt("TotalPlayCount", PlayCount);
        PlayerPrefs.Save();

        if (AchievementManager.Instance != null)
        {
            AchievementManager.Instance.ReportProgress(AchievementType.PlayCount, PlayCount);
        }


        int currentScore = ScoreManager != null ? ScoreManager.CurrentScore : 0;

        int bestScore = PlayerPrefs.GetInt(BestScoreKey, 0);
        bool isNewRecord = currentScore > bestScore;

        if (isNewRecord)
        {
            bestScore = currentScore;
            PlayerPrefs.SetInt(BestScoreKey, bestScore);
            PlayerPrefs.Save();

            if (FireBaseManager.Instance != null)
                FireBaseManager.Instance.SaveScoreToDatabase(currentScore);

            if (LobbyUI != null)
                LobbyUI.LoadBestScore();
        }

        if (GameOverUI != null)
            GameOverUI.Show(currentScore, bestScore, !bHasRevivedThisGame);
    }

    public void OnClickAdReviveButton()
    {
        if (AdManager.Instance != null)
        {
            AdManager.Instance.ShowRewardedAd(OnReviveSuccess);
        }
        else
        {
            // ������ �׽�Ʈ ���̰ų� AdManager�� ���� ���� �׳� ��� ��Ȱ ó�� (�׽�Ʈ�� ��� �ڵ�)
            OnReviveSuccess();
        }
    }

    private void OnReviveSuccess()
    {
        bHasRevivedThisGame = true; // ��Ȱ ��ȸ ��� �Ϸ�

        if (GameOverUI != null) GameOverUI.Hide();

        if (CurrentPlayer != null && CurrentPlayer.HealthComponent != null)
        {
            CurrentPlayer.HealthComponent.Revive(1); // ��Ʈ 1���� ��Ȱ (���Ѵٸ� MaxHealth�� ��Ȱ ����)
        }

        // ��Ȱ���ڸ��� ������ϴ� ���� ���� ���� �÷��̾� �ֺ��� ���� ���������ϴ�.
        //ClearEnemiesNearPlayer();

        if (ScoreManager != null)
        {
            ScoreManager.ResetCombo();
        }

        // ���¸� �ٽ� �÷��̾� ������ �ǵ����ϴ�.
        ChangeState(GameState.PlayerTurn);

        // UI�� �ΰ��� ���·� �ǵ����ϴ�.
        if (UITransition != null) UITransition.SlideToGame();
    }

    private void ClearEnemiesNearPlayer()
    {
        if (EnemyManager == null || CurrentPlayer == null) return;

        List<EnemyBase> EnemiesToRemove = new List<EnemyBase>();

        foreach (EnemyBase Enemy in EnemyManager.ActiveEnemies)
        {
            // �÷��̾�� �Ÿ��� 1 �̳��� (�����¿� �� �밢��) ������ ������ ã���ϴ�.
            int DistX = Mathf.Abs(Enemy.CurrentX - CurrentPlayer.CurrentX);
            int DistY = Mathf.Abs(Enemy.CurrentY - CurrentPlayer.CurrentY);

            if (DistX <= 2 && DistY <= 2)
            {
                EnemiesToRemove.Add(Enemy);
            }
        }

        // ã�Ƴ� ������ �Ͷ߷��ݴϴ�.
        foreach (EnemyBase Enemy in EnemiesToRemove)
        {
            Enemy.Die(); // (����: Die �ȿ� EnemyManager.RemoveEnemy ó���� �Ǿ��ִ��� Ȯ�� �ʿ�)
            // ī�޶� ��鸲�̳� ���� ����Ʈ�� �ָ� Ÿ�ݰ��� �ξ� �����ϴ�!
        }

        // �ʿ��ϴٸ� ���� ����Ʈ �Ҹ� ���
        // if (AudioManager.Instance != null) AudioManager.Instance.PlaySFX(SfxType.EnemyDie);
    }

    public void RetryGame()
    {
        StartGame(true);
    }

    public void OpenSettings()
    {
        if (SettingsUI != null) SettingsUI.Show();

        if (CurrentState != GameState.Lobby)
        {
            Time.timeScale = 0f;
        }
    }

    public void CloseSettings()
    {
        if (SettingsUI != null) SettingsUI.Hide();
        Time.timeScale = 1f;
    }

    public void ReturnToLobby()
    {
        Time.timeScale = 1f;

        ChangeState(GameState.Lobby);

        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayBGM(BgmType.Lobby);

        ClearEnemies();

        //if (BoardRenderer != null) BoardRenderer.gameObject.SetActive(false);
        //if (CurrentPlayer != null) CurrentPlayer.gameObject.SetActive(false);

        if (CurrentPlayer != null) CurrentPlayer.ResetPlayer();

        //if (LobbyUIPanel != null) LobbyUIPanel.SetActive(true);
        //if (GameUIPanel != null) GameUIPanel.SetActive(false);

        if (UITransition != null)
            UITransition.SlideToLobby();

        if (GameOverUI != null) GameOverUI.Hide();

        if (ItemManager != null) ItemManager.ClearItem();

        if (LobbyUI != null) LobbyUI.LoadBestScore();
    }

    private void ClearEnemies()
    {
        if (TurnManager != null) TurnManager.StopAllCoroutines();
        if (EnemyManager != null) EnemyManager.StopAllCoroutines();

        if (EnemyManager != null)
        {
            foreach (EnemyBase Enemy in EnemyManager.ActiveEnemies)
            {
                if (Enemy != null)
                {
                    PoolManager.Instance.ReturnToPool(Enemy.gameObject);
                }
            }
            EnemyManager.ActiveEnemies.Clear();
        }
    }

    public void OpenCollectionUI()
    {
        // �κ� ������ ���� �������� ��� �ڵ� (���� �߿� �� ������)
        if (CurrentState == GameState.Lobby)
        {
            if (CollectionUI != null && !CollectionUI.isActiveAndEnabled)
            {
                CollectionUI.Show();
            }
        }
    }
}
