using Firebase;
using Firebase.Auth;
using Firebase.Database;
using Firebase.Extensions;
using GooglePlayGames;
using GooglePlayGames.BasicApi;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;
using static UnityEngine.UIElements.UxmlAttributeDescription;

public class FireBaseManager : MonoBehaviour
{
    public static FireBaseManager Instance;

    private DatabaseReference DBReference;
    private bool bIsFireBaseReady = false;

    private FirebaseAuth auth;
    private FirebaseUser user;
    [HideInInspector] public bool bIsLoginSequenceFinished = false;

    public bool bUseFirebase = false;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(transform.root.gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public IEnumerator InitializeFirebaseRoutine()
    {
        if (bUseFirebase == false)
        {
            Debug.Log("[FireBaseManager] ���̾�̽��� ������� ���� ����.");
            yield break; // �ڷ�ƾ ��� ����
        }

        bool bWaitFirebase = true;

        FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(task =>
        {
            if (task.Result == DependencyStatus.Available)
            {
                DBReference = FirebaseDatabase.DefaultInstance.RootReference;
                bIsFireBaseReady = true;
                Debug.Log("[FireBaseManager] �ʱ�ȭ ���� �� ���� �Ϸ�");
            }
            else
            {
                Debug.LogError($"[FireBaseManager] �ʱ�ȭ ����: {task.Result}");
            }

            bWaitFirebase = false;
        });

        // �񵿱� �۾��� ���� ������ ���
        yield return new WaitUntil(() => bWaitFirebase == false);
    }

    public void SaveScoreToDatabase(int FinalScore)
    {
        if (!bUseFirebase || !bIsFireBaseReady || DBReference == null || user == null)
        {
            Debug.LogWarning("[FireBaseManager] ���� ���� �Ұ� ����.");
            return;
        }

        string uid = user.UserId;
        DatabaseReference userRef = DBReference.Child("Leaderboard").Child(uid);

        userRef.Child("Scroe").GetValueAsync().ContinueWithOnMainThread(task =>
        {
            if (task.IsFaulted)
            {
                Debug.LogError("[FireBaseManager] ���� ��ȸ ����: " + task.Exception);
                return;
            }
            int existingScore = 0;
            if(task.Result.Exists && task.Result.Value != null)
                int.TryParse(task.Result.Value.ToString(), out existingScore);

            if (FinalScore <= existingScore) return;

            Dictionary<string, object> updates = new Dictionary<string, object>
            {
                ["Score"] = FinalScore,
                ["Name"] = user.DisplayName ?? "",
                ["PhotoUrl"] = user.PhotoUrl != null ? user.PhotoUrl.ToString() : ""
            };

            userRef.UpdateChildrenAsync(updates).ContinueWithOnMainThread(updateTask => 
            {
                if (updateTask.IsFaulted)
                    Debug.LogError("[FireBaseManager] ���� ���� ����: " + updateTask.Exception);
                else
                    Debug.Log("[FireBaseManager] �ű�� ���� �Ϸ�!");
            });
        });
    }

    public Task<List<RankData>> GetTopRankingsAsync(int limit = 50)
    {
        var tcs = new TaskCompletionSource<List<RankData>>();

        if (!bUseFirebase || !bIsFireBaseReady)
        {
            tcs.SetResult(new List<RankData>());
            return tcs.Task;
        }

        FirebaseDatabase.DefaultInstance.RootReference
            .Child("Leaderboard")
            .OrderByChild("Score")
            .LimitToLast(limit)
            .GetValueAsync()
            .ContinueWithOnMainThread(task =>
            {
                if (task.IsFaulted)
                {
                    Debug.LogError("[FireBaseManager] ��ŷ ��ȸ ����.");
                    tcs.SetResult(new List<RankData>());
                    return;
                }

                var snapshots = new List<DataSnapshot>();
                foreach (DataSnapshot child in task.Result.Children)
                    snapshots.Add(child);
                snapshots.Reverse(); // ���� ���� �� ����

                var result = new List<RankData>();
                for (int i = 0; i < snapshots.Count; i++)
                {
                    DataSnapshot data = snapshots[i];
                    result.Add(new RankData
                    {
                        Rank = i + 1,
                        Uid = data.Key,
                        Name = data.Child("Name").Value?.ToString() ?? "",
                        Score = data.Child("Score").Value?.ToString() ?? "0",
                        PhotoUrl = data.HasChild("PhotoUrl")
                            ? data.Child("PhotoUrl").Value?.ToString() ?? ""
                            : ""
                    });
                }

                tcs.SetResult(result);
            });

        return tcs.Task;
    }

    public Task<RankData> GetMyRankAsync()
    {
        var tcs = new TaskCompletionSource<RankData>();

        if (!bUseFirebase || !bIsFireBaseReady || user == null)
        {
            tcs.SetResult(null);
            return tcs.Task;
        }

        string myUid = user.UserId;

        DBReference.Child("Leaderboard").Child(myUid)
            .GetValueAsync()
            .ContinueWithOnMainThread(task =>
            {
                if (!task.IsCompletedSuccessfully || !task.Result.Exists)
                {
                    tcs.SetResult(null);
                    return;
                }

                DataSnapshot myData = task.Result;
                int myScore = 0;
                int.TryParse(myData.Child("Score").Value?.ToString(), out myScore);
                string myName = myData.Child("Name").Value?.ToString() ?? "";
                string myPhoto = myData.HasChild("PhotoUrl")
                    ? myData.Child("PhotoUrl").Value?.ToString() ?? ""
                    : "";

                // �� ���� �̻��� ��� �� = �� ����
                DBReference.Child("Leaderboard")
                    .OrderByChild("Score")
                    .StartAt(myScore)
                    .GetValueAsync()
                    .ContinueWithOnMainThread(countTask =>
                    {
                        int myRank = countTask.IsCompletedSuccessfully
                            ? (int)countTask.Result.ChildrenCount
                            : -1;

                        tcs.SetResult(new RankData
                        {
                            Rank = myRank,
                            Uid = myUid,
                            Name = myName,
                            Score = myScore.ToString(),
                            PhotoUrl = myPhoto
                        });
                    });
            });

        return tcs.Task;
    }

    public IEnumerator GoogleLoginRoutine()
    {
        if (bUseFirebase == false)
        {
            bIsLoginSequenceFinished = true;
            yield break;
        }

        bIsLoginSequenceFinished = false; // �α��� ���� �� ���·� ����
        auth = FirebaseAuth.DefaultInstance;

        Debug.Log("[FireBaseManager] ���� �α����� �õ��մϴ�...");
        PlayGamesPlatform.Instance.Authenticate(ProcessAuthentication);

        // �α����� �����ϵ� �����ϵ� ������ ���� ������ BootManager�� ������ ����
        yield return new WaitUntil(() => bIsLoginSequenceFinished == true);
    }

    internal void ProcessAuthentication(SignInStatus status)
    {
        if (status == SignInStatus.Success)
        {
            PlayGamesPlatform.Instance.RequestServerSideAccess(true, authCode =>
            {
                LoginToFirebase(authCode);
            });
        }
        else
        {
            Debug.LogError("GPGS �α��� ���� �Ǵ� ��ҵ�: " + status);
            bIsLoginSequenceFinished = true; // �����ص� �κ�δ� ���� �ϹǷ� ������ ����
        }
    }

    private void LoginToFirebase(string authCode)
    {
        Credential credential = PlayGamesAuthProvider.GetCredential(authCode);
        auth.SignInWithCredentialAsync(credential).ContinueWithOnMainThread(task =>
        {
            if (task.IsCanceled || task.IsFaulted)
            {
                Debug.LogError("���̾�̽� ���� ����: " + task.Exception);
            }
            else
            {
                user = task.Result;
                Debug.Log($"���̾�̽� �α��� ���� ����! ȯ���մϴ�: {user.DisplayName}");
            }
            bIsLoginSequenceFinished = true; // ����/���� ���� ������� ���� �ѱ�� ���� ����
        });
    }

    public string GetCurrentUserUid() => user?.UserId ?? "";
    public bool IsLoggedIn => user != null;
}
