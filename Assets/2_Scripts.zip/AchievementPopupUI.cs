using UnityEngine;
using DG.Tweening;
using UnityEngine.Localization.Components;
using UnityEngine.UI; 

public class AchievementPopupUI : MonoBehaviour
{
    [Header("Achievement UI")]
    public GameObject AchievementPopup;     // �˸�â ��� �г�
    public Image RewardPreviewImage;

    [Header("Localization Tables")]
    // ���̺� �̸� 2�� ����
    public string AchievementTableName = "Achievement_Table";
    public string ItemTableName = "Item_Table";

    [Header("Localization Texts")]
    public LocalizeStringEvent TitleTextEvent; // "1,000�� �޼�!" �ؽ�Ʈ
    public LocalizeStringEvent ItemNameTextEvent; // "Ȳ�� ��� ȹ��" �ؽ�Ʈ

    private void Awake()
    {
        if (AchievementPopup != null) AchievementPopup.SetActive(false);
    }

    private void OnEnable()
    {
        AchievementManager.OnAchievementUnlocked += ShowPopup;
    }

    private void OnDisable()
    {
        AchievementManager.OnAchievementUnlocked -= ShowPopup;
    }

    private void ShowPopup(AchievementEntry data)
    {
        if (AchievementPopup == null) return;

        // 1. �ٱ��� Ű�� ���� (�ڵ� ���� ��)
        if (TitleTextEvent != null)
            TitleTextEvent.StringReference.SetReference(AchievementTableName, data.TitleKey);

        if (ItemNameTextEvent != null)
            ItemNameTextEvent.StringReference.SetReference(ItemTableName, data.RewardItem.ItemID);

        if (RewardPreviewImage != null && data.RewardItem is SkinData skinData)
        {
            if (skinData.PlayerSprite != null) 
            {
                RewardPreviewImage.sprite = skinData.PlayerSprite;
            }
            RewardPreviewImage.color = skinData.PlayerColor;
            RewardPreviewImage.preserveAspect = true;
        }

        // 2. �˸�â ���� �ִϸ��̼�
        AchievementPopup.SetActive(true);
        AchievementPopup.transform.localScale = Vector3.zero;
        AchievementPopup.transform.DOKill();

        // �층! �ϰ� ��Ÿ���ٰ�
        AchievementPopup.transform.DOScale(Vector3.one, 0.5f).SetEase(Ease.OutBack).OnComplete(() => {
            // 3�� �ڿ�
            DOVirtual.DelayedCall(3.0f, () => {
                // ������ �����
                AchievementPopup.transform.DOScale(Vector3.zero, 0.3f).SetEase(Ease.InBack).OnComplete(() => AchievementPopup.SetActive(false));
            });
        });
    }
}